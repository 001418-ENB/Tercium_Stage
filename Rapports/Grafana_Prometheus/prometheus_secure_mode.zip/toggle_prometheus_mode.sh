#!/bin/bash

SCRIPT="/usr/local/bin/start_prometheus.sh"
CURRENT=$(grep "PROM_SECURE=" "$SCRIPT" | cut -d'=' -f2)

if [ "$CURRENT" = "true" ]; then
  sudo sed -i 's/PROM_SECURE=true/PROM_SECURE=false/' "$SCRIPT"
  echo "[INFO] Mode sécurisé désactivé : API d'administration activée."
else
  sudo sed -i 's/PROM_SECURE=false/PROM_SECURE=true/' "$SCRIPT"
  echo "[INFO] Mode sécurisé activé : API d'administration désactivée."
fi

# Redémarrer Prometheus pour appliquer les changements
sudo systemctl restart prometheus
