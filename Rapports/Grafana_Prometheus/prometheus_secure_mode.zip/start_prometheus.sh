#!/bin/bash

# Activer ou désactiver le mode sécurisé (admin API désactivée)
PROM_SECURE=true

# Paramètres de base
ARGS="--config.file=/etc/prometheus/prometheus.yml \
      --storage.tsdb.path=/var/lib/prometheus \
      --web.console.templates=/opt/prometheus/consoles \
      --web.console.libraries=/opt/prometheus/console_libraries \
      --web.listen-address=0.0.0.0:9091"

# Ajout conditionnel du flag de sécurité
if [ "$PROM_SECURE" = "true" ]; then
  ARGS="$ARGS --web.enable-admin-api=false"
fi

# Lancement
exec /opt/prometheus/prometheus $ARGS
